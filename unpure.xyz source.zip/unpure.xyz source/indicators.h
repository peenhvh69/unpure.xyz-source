#pragma once

class hud_indicators {
public:
	void Indicators();
	void StateIndicators();
	int	m_width, m_height;
};

extern hud_indicators g_indicators;