#include "includes.h"

//void Hooks::PlaySound( const char* sample ) {
//
//}